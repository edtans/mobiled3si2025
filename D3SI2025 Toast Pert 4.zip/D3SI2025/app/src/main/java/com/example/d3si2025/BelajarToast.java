package com.example.d3si2025;

import android.os.Bundle;
import android.view.View;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class BelajarToast extends AppCompatActivity {

    //deklarasi variabel
    private Switch swifi_code;
    private TextView txtKeterangan_code;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_belajar_toast);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        //konfigurasi
        swifi_code = (Switch) findViewById(R.id.swifi);
        txtKeterangan_code = (TextView) findViewById(R.id.txtKeterangan);

        //ketika switch diklik
        swifi_code.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //txtKeterangan_code.setText("switch diklik woy");
                if (swifi_code.isChecked())
                {
                    txtKeterangan_code.setText("nyala");
                    txtKeterangan_code.setTextSize(50);
                    Toast.makeText(getApplicationContext(),
                            "nyala",
                            Toast.LENGTH_SHORT).show();
                }
                else
                {
                    txtKeterangan_code.setText("mati");
                    txtKeterangan_code.setTextSize(20);
                }

            }
        });








    }
}